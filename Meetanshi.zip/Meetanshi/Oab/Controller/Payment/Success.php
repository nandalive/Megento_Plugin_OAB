<?php

namespace Meetanshi\Oab\Controller\Payment;

use Meetanshi\Oab\Controller\Main;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\App\CsrfAwareActionInterface;
use Magento\Framework\App\Request\InvalidRequestException;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Sales\Model\Order;
use Magento\Sales\Model\Order\Invoice;
use Magento\Sales\Model\Order\Payment\Transaction;

/**
 * Class Success
 * @package Meetanshi\Oab\Controller\Payment
 */
class Success extends Main implements CsrfAwareActionInterface
{
    /**
     * @inheritDoc
     */
    public function createCsrfValidationException(RequestInterface $request): ?InvalidRequestException
    {
        return null;
    }

    /**
     * @inheritDoc
     */
    public function validateForCsrf(RequestInterface $request): ?bool
    {
        return true;
    }

    /**
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\ResultInterface|void
     * @throws \Magento\Framework\Exception\LocalizedException
     * @throws \Magento\Framework\Exception\MailException
     */
    public function execute()
    {
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        $params = $this->request->getParams();
        $this->logger->error("Response Received ...");
        $this->logger->info(serialize($params));
        $ipayPipe = $this->_objectManager->create('\Meetanshi\Oab\Model\IPayOabPipe');
        $resourceKey = $this->helper->getResourceKey();
        $ipayPipe->setkey($resourceKey);
        $trandata = isset($params['trandata']) ? $params['trandata'] : $params['trandata'];
        $ipayPipe->setLogger($this->logger);
        $result = $ipayPipe->parseEncryptedRequest($trandata);
        $this->logger->info("Encrypted Result => " . $result);
        if ($result == 0) {
            if ($ipayPipe->geterror() != null && $ipayPipe->geterror() != "") {
                $this->messageManager->addErrorMessage(__('Transaction is not approved by the bank'));
                $this->checkoutSession->restoreQuote();
                $this->_redirect('checkout/cart');
            } else {
                $this->logger->info("Encrypted Result => " . $ipayPipe->getresult());
                $order = $this->orderFactory->create()->loadByIncrementId($ipayPipe->gettrackId());
                if ($ipayPipe->getresult() == 'CAPTURED') {
                    $payment = $order->getPayment();

                    $paymentID = $ipayPipe->getpaymentId();
                    $presult = $ipayPipe->getresult();
                    $tranId = $ipayPipe->gettransId();
                    $ref = $ipayPipe->getref();
                    $trackId = $ipayPipe->gettrackId();
                    $this->logger->info("Payment ID => " . $paymentID . ' ' . "Result => " . $presult . ' ' . "REF => " . $ref . ' ' . "Track Id => " . $trackId);
                    $payment->setTransactionId($tranId);
                    $payment->setLastTransId($tranId);
                    $payment->setAdditionalInformation('payment_id', $paymentID);
                    $payment->setAdditionalInformation('result', $presult);
                    $payment->setAdditionalInformation('tran_id', $tranId);
                    $payment->setAdditionalInformation('reference_id', $ref);
                    $payment->setAdditionalInformation('track_id', $trackId);

                    $payment->setAdditionalInformation((array)$payment->getAdditionalInformation());
                    $trans = $this->transactionBuilder;
                    $transaction = $trans->setPayment($payment)->setOrder($order)->setTransactionId($tranId)->setAdditionalInformation((array)$payment->getAdditionalInformation())->setFailSafe(true)->build(Transaction::TYPE_CAPTURE);

                    $payment->setParentTransactionId(null);

                    $payment->save();

                    $this->orderSender->notify($order);
                    $order->setState(Order::STATE_PROCESSING, true);
                    $order->setStatus(Order::STATE_PROCESSING);

                    $order->addStatusHistoryComment(__('Transaction is approved by the bank'), Order::STATE_PROCESSING)->setIsCustomerNotified(true);

                    $order->save();

                    $transaction->save();
                    $this->checkoutSession->setLastSuccessQuoteId($order->getQuoteId());
                    $this->checkoutSession->setLastQuoteId($order->getQuoteId());
                    $this->checkoutSession->setLastOrderId($order->getId());
                    if ($this->helper->isAutoInvoice()) {
                        if (!$order->canInvoice()) {
                            $order->addStatusHistoryComment('Sorry, Order cannot be invoiced.', false);
                        }
                        $invoice = $this->invoiceService->prepareInvoice($order);
                        if (!$invoice) {
                            $order->addStatusHistoryComment('Can\'t generate the invoice right now.', false);
                        }
                        if (!$invoice->getTotalQty()) {
                            $order->addStatusHistoryComment('Can\'t generate an invoice without products.', false);
                        }
                        $invoice->setRequestedCaptureCase(Invoice::CAPTURE_OFFLINE);
                        $invoice->register();
                        $invoice->getOrder()->setCustomerNoteNotify(true);
                        $invoice->getOrder()->setIsInProcess(true);
                        $transactionSave = $this->transactionFactory->create()->addObject($invoice)->addObject($invoice->getOrder());
                        $transactionSave->save();

                        try {
                            $this->invoiceSender->send($invoice);
                        } catch (\Magento\Framework\Exception\LocalizedException $e) {
                            $order->addStatusHistoryComment('Can\'t send the invoice Email right now.', false);
                        }

                        $order->addStatusHistoryComment('Automatically Invoice Generated.', false);
                        $order->save();
                    }
                    $this->_redirect('checkout/onepage/success');
                    return;
                } else {
                    $msg = 'Your transaction is not approved by bank.';
                    $order->addStatusHistoryComment($msg, Order::STATE_CANCELED)->setIsCustomerNotified(true);
                    $order->cancel();
                    $order->save();
                    $this->checkoutSession->restoreQuote();
                    $this->_redirect('checkout/cart');
                    return;
                }
            }

        } else {
            $this->messageManager->addErrorMessage(__('Transaction is not approved by the bank'));
            $this->checkoutSession->restoreQuote();
            $this->_redirect('checkout/cart');
            return;
        }
    }
}
