<?php

namespace Meetanshi\Oab\Helper;

use Magento\Framework\App\Helper\Context;
use Magento\Framework\Encryption\EncryptorInterface;
use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Store\Model\ScopeInterface;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\App\Request\Http;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\View\Asset\Repository;

class Data extends AbstractHelper
{
    const CONFIG_OAB_ACTIVE = 'payment/oab/active';

    const CONFIG_OAB_LANNGUAGE = 'payment/oab/lang';

    const CONFIG_OAB_ALIAS = 'payment/oab/alias';

    const CONFIG_OAB_TRANPORTAL_ID = 'payment/oab/tranportalId';

    const CONFIG_OAB_TRANPORTAL_PWD = 'payment/oab/tranportalPwd';

    const CONFIG_OAB_RESOURCE_KEY = 'payment/oab/resourceKey';
    
    const CONFIG_OAB_LIVE_MODE = 'payment/oab/liveMode';

    const CONFIG_OAB_INSTRUCTIONS = 'payment/oab/instructions';

    const CONFIG_OAB_INVOICE = 'payment/oab/allow_invoice';

    const CONFIG_OAB_LOGO = 'payment/oab/show_logo';
    /**
     * @var Http
     */
    protected $request;
    /**
     * @var DirectoryList
     */
    protected $directoryList;
    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;
    /**
     * @var Repository
     */
    private $repository;
    /**
     * @var RequestInterface
     */
    private $requestInterface;
    /**
     * @var EncryptorInterface
     */
    protected $encryptor;

    /**
     * Data constructor.
     * @param Context $context
     * @param EncryptorInterface $encryptor
     * @param DirectoryList $directoryList
     * @param StoreManagerInterface $storeManager
     * @param Repository $repository
     * @param RequestInterface $requestInterface
     * @param Http $request
     */
    public function __construct(Context $context, EncryptorInterface $encryptor, DirectoryList $directoryList, StoreManagerInterface $storeManager, Repository $repository, RequestInterface $requestInterface, Http $request)
    {
        parent::__construct($context);
        $this->encryptor = $encryptor;
        $this->directoryList = $directoryList;
        $this->storeManager = $storeManager;
        $this->requestInterface = $requestInterface;
        $this->request = $request;
        $this->repository = $repository;
    }

    /**
     * @return mixed
     */
    public function getAlias()
    {
        return $this->scopeConfig->getValue(self::CONFIG_OAB_ALIAS, ScopeInterface::SCOPE_STORE);
    }

    public function getTranportalId()
    {
        return $this->scopeConfig->getValue(self::CONFIG_OAB_TRANPORTAL_ID, ScopeInterface::SCOPE_STORE);
    }

    public function getTranportalPwd()
    {
        return $this->scopeConfig->getValue(self::CONFIG_OAB_TRANPORTAL_PWD, ScopeInterface::SCOPE_STORE);
    }

    
    public function getResourceKey()
    {
        return $this->scopeConfig->getValue(self::CONFIG_OAB_RESOURCE_KEY, ScopeInterface::SCOPE_STORE);
    }

    public function getLiveMode()
    {
        return $this->scopeConfig->getValue(self::CONFIG_OAB_LIVE_MODE, ScopeInterface::SCOPE_STORE);
    }

    /**
     * @return mixed
     */
    public function isAutoInvoice()
    {
        return $this->scopeConfig->getValue(self::CONFIG_OAB_INVOICE, ScopeInterface::SCOPE_STORE);
    }

    public function getPaymentLanguage()
    {
        return $this->scopeConfig->getValue(self::CONFIG_OAB_LANNGUAGE, ScopeInterface::SCOPE_STORE);
    }

    /**
     * @return mixed
     */
    public function showLogo()
    {
        return $this->scopeConfig->getValue(self::CONFIG_OAB_LOGO, ScopeInterface::SCOPE_STORE);
    }

    /**
     * @return string
     */
    public function getPaymentLogo()
    {
        $params = ['_secure' => $this->request->isSecure()];
        return $this->repository->getUrlWithParams('Meetanshi_Oab::images/oab.png', $params);
    }

    /**
     * @return mixed
     */
    public function getPaymentInstructions()
    {
        return $this->scopeConfig->getValue(self::CONFIG_OAB_INSTRUCTIONS, ScopeInterface::SCOPE_STORE);
    }

    public function getSuccessUrl($storeId)
    {
        $baseUrl = $this->storeManager->getStore($storeId)->getBaseUrl();
        return $baseUrl . "oab/payment/success";
    }

    public function getErrorUrl()
    {
        $baseUrl = $this->storeManager->getStore()->getBaseUrl();
        return $baseUrl . "oab/payment/cancel";
    }

}
