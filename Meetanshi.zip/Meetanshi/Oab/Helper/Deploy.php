<?php

namespace Meetanshi\Oab\Helper;

use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;
use Magento\Framework\Filesystem;

/**
 * Class Deploy
 * @package Meetanshi\Oab\Helper
 */
class Deploy extends AbstractHelper
{
    const FILE_PERMISSIONS = 0666;
    const DIR_PERMISSIONS = 0777;

    /**
     * @var Filesystem\Directory\WriteInterface
     */
    protected $write;
    /**
     * @var Filesystem\Directory\ReadInterface
     */
    protected $read;
    /**
     * @var Filesystem
     */
    protected $filesystem;

    /**
     * Deploy constructor.
     * @param Context $context
     * @param Filesystem $filesystem
     * @throws \Magento\Framework\Exception\FileSystemException
     */
    public function __construct(Context $context, Filesystem $filesystem)
    {
        parent::__construct($context);

        $this->filesystem = $filesystem;
        $this->write = $filesystem->getDirectoryWrite(DirectoryList::ROOT);
        $this->read = $filesystem->getDirectoryRead(DirectoryList::ROOT);
    }

    /**
     * @param $folder
     */
    public function deployOab($folder)
    {
        $from = $this->read->getRelativePath($folder);
        $this->moveFiles($from, '');
    }

    /**
     * @param $from
     * @param $to
     * @throws \Magento\Framework\Exception\FileSystemException
     */
    public function moveFiles($from, $to)
    {
        $baseName = basename($from);
        $files = $this->read->readRecursively($from);
        array_unshift($files, $from);

        foreach ($files as $file) {
            $fileName = $this->getFilePath(
                $file,
                $from,
                ltrim($to . '/' . $baseName, '/')
            );

            if ($this->read->isExist($fileName)) {
                continue;
            }

            if ($this->read->isFile($file)) {
                $this->write->copyFile($file, $fileName);

                $this->write->changePermissions(
                    $fileName,
                    self::FILE_PERMISSIONS
                );
            } elseif ($this->read->isDirectory($file)) {
                $this->write->create($fileName);

                $this->write->changePermissions(
                    $fileName,
                    self::DIR_PERMISSIONS
                );
            }
        }
    }

    /**
     * @param $path
     * @param $from
     * @param $to
     * @return string|string[]
     */
    protected function getFilePath($path, $from, $to)
    {
        return str_replace($from, $to, $path);
    }
}
