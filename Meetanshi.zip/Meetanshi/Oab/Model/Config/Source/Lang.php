<?php

namespace Meetanshi\Oab\Model\Config\Source;

use Magento\Framework\Option\ArrayInterface;

class Lang implements Arrayinterface
{
    public function toOptionArray()
    {
        return [['value' => 'ENG', 'label' => __('English')], ['value' => 'ARA', 'label' => __('Arabic')],];
    }
}
