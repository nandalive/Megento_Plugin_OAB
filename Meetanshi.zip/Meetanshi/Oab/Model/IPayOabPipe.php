<?php

namespace Meetanshi\Oab\Model;

use Psr\Log\LoggerInterface;

/**
 * Class IPayOabPipe
 * @package Meetanshi\Oab\Model
 */
class IPayOabPipe
{
    /**
     * @var string
     */
    protected $id = "";
    /**
     * @var string
     */
    protected $pwd = "";

        /**
     * @var string
     */
    protected $liveMode = "";

    /**
     * @var string
     */
    protected $action = "";
    /**
     * @var string
     */
    protected $transId = "";
    /**
     * @var string
     */
    protected $amt = "";
    /**
     * @var string
     */
    protected $responseURL = "";
    /**
     * @var string
     */
    protected $trackId = "";
    /**
     * @var string
     */
    protected $udf1 = "";
    /**
     * @var string
     */
    protected $udf2 = "";
    /**
     * @var string
     */
    protected $udf3 = "";
    /**
     * @var string
     */
    protected $udf4 = "";
    /**
     * @var string
     */
    protected $udf5 = "";
    /**
     * @var string
     */
    protected $paymentPage = "";
    /**
     * @var string
     */
    protected $paymentId = "";
    /**
     * @var string
     */
    protected $result = "";
    /**
     * @var string
     */
    protected $auth = "";
    /**
     * @var string
     */
    protected $ref = "";
    /**
     * @var string
     */
    protected $avr = "";
    /**
     * @var string
     */
    protected $date = "";
    /**
     * @var string
     */
    protected $currency = "";
    /**
     * @var string
     */
    protected $errorURL = "";
    /**
     * @var string
     */
    protected $language = "";
    /**
     * @var string
     */
    protected $error = "";
    /**
     * @var string
     */
    protected $error_text = "";
    /**
     * @var string
     */
    protected $rawResponse = "";
    /**
     * @var string
     */
    protected $alias = "";
    /**
     * @var string
     */
    protected $debugMsg = "";
    /**
     * @var string
     */
    protected $responseCode = "";
    /**
     * @var string
     */
    protected $zip = "";
    /**
     * @var string
     */
    protected $addr = "";
    /**
     * @var string
     */
    protected $member = "";
    /**
     * @var string
     */
    protected $cvv2 = "";
    /**
     * @var string
     */
    protected $cvv2Verification = "";
    /**
     * @var string
     */
    protected $type = "";
    /**
     * @var string
     */
    protected $card = "";
    /**
     * @var string
     */
    protected $expDay = "";
    /**
     * @var string
     */
    protected $expMonth = "";
    /**
     * @var string
     */
    protected $expYear = "";
    /**
     * @var string
     */
    protected $eci = "";
    /**
     * @var string
     */
    protected $cavv = "";
    /**
     * @var string
     */
    protected $xid = "";
    /**
     * @var string
     */
    protected $resourcePath = "";
    /**
     * @var string
     */
    protected $acsurl = "";
    /**
     * @var string
     */
    protected $pareq = "";
    /**
     * @var string
     */
    protected $pares = "";
    /**
     * @var string
     */
    protected $error_service_tag = "";
    /**
     * @var string
     */
    protected $keystorePath = "";
    /**
     * @var string
     */
    protected $seperator = "\\";
    /**
     * @var string
     */
    protected $sep = "/";
    /**
     * @var string
     */
    protected $webAddress = "";
    /**
     * @var string
     */
    protected $key = "";
    /**
     * @var string
     */
    protected $initializationVector = "";
    /**
     * @var string
     */
    protected $ivrFlag = "";
    /**
     * @var string
     */
    protected $npc356chphoneidformat = "";
    /**
     * @var string
     */
    protected $npc356chphoneid = "";
    /**
     * @var string
     */
    protected $npc356shopchannel = "";
    /**
     * @var string
     */
    protected $npc356availauthchannel = "";
    /**
     * @var string
     */
    protected $npc356pareqchannel = "";
    /**
     * @var string
     */
    protected $npc356itpcredential = "";
    /**
     * @var string
     */
    protected $authDataName = "";
    /**
     * @var string
     */
    protected $authDatastrlen = "";
    /**
     * @var string
     */
    protected $authDataType = "";
    /**
     * @var string
     */
    protected $authDataLabel = "";
    /**
     * @var string
     */
    protected $authDataPrompt = "";
    /**
     * @var string
     */
    protected $authDataEncryptKey = "";
    /**
     * @var string
     */
    protected $authDataEncryptType = "";
    /**
     * @var string
     */
    protected $authDataEncryptMandatory = "";
    /**
     * @var string
     */
    protected $ivrPasswordStatus = "";
    /**
     * @var string
     */
    protected $ivrPassword = "";
    /**
     * @var string
     */
    protected $itpauthtran = "";
    /**
     * @var string
     */
    protected $itpauthiden = "";
    /**
     * @var string
     */
    protected $url = "";
    /**
     * @var string
     */
    protected $savedcard = "";
    /**
     * @var string
     */
    protected $paymentdebitId = "";
    /**
     * @var string
     */
    protected $paymentUrl = "";
    /**
     * @var string
     */
    protected $tokenFlg = "";
    /**
     * @var string
     */
    protected $tokenNumber = "";
    /**
     * @var string
     */
    protected $tokenCustomerId = "";
    /**
     * @var
     */
    protected $keystore;
    /**
     * @var
     */
    protected $parseResourceOab;

    /**
     * @var LoggerInterface
     */
    protected $logger;

    public function setLogger($val)
    {
        $this->logger = $val;
    }

    /**
     * @return string
     */
    public function gettokenCustomerId()
    {
        return $this->tokenCustomerId;
    }

    /**
     * @return string
     */
    public function gettokenFlg()
    {
        return $this->tokenFlg;
    }

    /**
     * @param $val
     */
    public function settokenNumber($val)
    {
        $this->tokenNumber = $val;
    }

    /**
     * @param $val
     */
    public function settokenFlg($val)
    {
        $this->tokenFlg = $val;
    }

    /**
     * @return string
     */
    public function getid()
    {
        return $this->id;
    }

    /**
     * @return string
     */
    public function getaction()
    {
        return $this->action;
    }

    /**
     * @return string
     */
    public function gettransId()
    {
        return $this->transId;
    }

    /**
     * @return string
     */
    public function getamt()
    {
        return $this->amt;
    }

    /**
     * @return string
     */
    public function getresponseURL()
    {
        return $this->responseURL;
    }

    /**
     * @return string
     */
    public function gettrackId()
    {
        return $this->trackId;
    }

    /**
     * @return string
     */
    public function getudf1()
    {
        return $this->udf1;
    }

    /**
     * @return string
     */
    public function getudf2()
    {
        return $this->udf2;
    }

    /**
     * @return string
     */
    public function getudf3()
    {
        return $this->udf3;
    }

    /**
     * @return string
     */
    public function getudf4()
    {
        return $this->udf4;
    }

    /**
     * @return string
     */
    public function getudf5()
    {
        return $this->udf5;
    }

    /**
     * @return string
     */
    public function getpaymentPage()
    {
        return $this->paymentPage;
    }

    /**
     * @return string
     */
    public function getpaymentId()
    {
        return $this->paymentId;
    }

    /**
     * @return string
     */
    public function getresult()
    {
        return $this->result;
    }

    /**
     * @return string
     */
    public function getauth()
    {
        return $this->auth;
    }

    /**
     * @return string
     */
    public function getref()
    {
        return $this->ref;
    }

    /**
     * @return string
     */
    public function getavr()
    {
        return $this->avr;
    }

    /**
     * @return string
     */
    public function getDate()
    {
        return $this->date;
    }

    /**
     * @return string
     */
    public function getcurrency()
    {
        return $this->currency;
    }

    /**
     * @return string
     */
    public function geterrorURL()
    {
        return $this->errorURL;
    }

    /**
     * @return string
     */
    public function getlanguage()
    {
        return $this->language;
    }

    /**
     * @return string
     */
    public function geterror()
    {
        return $this->error;
    }

    /**
     * @return string
     */
    public function geterror_text()
    {
        return $this->error_text;
    }

    /**
     * @return string
     */
    public function getrawResponse()
    {
        return $this->rawResponse;
    }

    /**
     * @return string
     */
    public function getalias()
    {
        return $this->alias;
    }

    /**
     * @return string
     */
    public function getDebugMsg()
    {
        return $this->debugMsg;
    }

    /**
     * @return string
     */
    public function getresponseCode()
    {
        return $this->responseCode;
    }

    /**
     * @return string
     */
    public function getzip()
    {
        return $this->zip;
    }

    /**
     * @return string
     */
    public function getaddr()
    {
        return $this->addr;
    }

    /**
     * @return string
     */
    public function getmember()
    {
        return $this->member;
    }

    /**
     * @return string
     */
    public function getcvv2()
    {
        return $this->cvv2;
    }

    /**
     * @return string
     */
    public function getcvv2Verification()
    {
        return $this->cvv2Verification;
    }

    /**
     * @return string
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * @return string
     */
    public function getcard()
    {
        return $this->card;
    }

    /**
     * @return string
     */
    public function getexpDay()
    {
        return $this->expDay;
    }

    /**
     * @return string
     */
    public function getexpMonth()
    {
        return $this->expMonth;
    }

    /**
     * @return string
     */
    public function getexpYear()
    {
        return $this->expYear;
    }

    /**
     * @return string
     */
    public function geteci()
    {
        return $this->eci;
    }

    /**
     * @return string
     */
    public function getcavv()
    {
        return $this->cavv;
    }

    /**
     * @return string
     */
    public function getxid()
    {
        return $this->xid;
    }

    /**
     * @return string
     */
    public function getresourcePath()
    {
        return $this->resourcePath;
    }

    /**
     * @return string
     */
    public function getacsurl()
    {
        return $this->acsurl;
    }

    /**
     * @return string
     */
    public function getpareq()
    {
        return $this->pareq;
    }

    /**
     * @return string
     */
    public function getpares()
    {
        return $this->pares;
    }

    /**
     * @return string
     */
    public function geterror_service_tag()
    {
        return $this->error_service_tag;
    }

    /**
     * @return string
     */
    public function getkeystorePath()
    {
        return $this->keystorePath;
    }

    /**
     * @return string
     */
    public function getseperator()
    {
        return $this->seperator;
    }

    /**
     * @return string
     */
    public function getsep()
    {
        return $this->sep;
    }

    /**
     * @return string
     */
    public function getwebAddress()
    {
        return $this->webAddress;
    }

    /**
     * @return string
     */
    public function getkey()
    {
        return $this->key;
    }

    /**
     * @return string
     */
    public function getinitializationVector()
    {
        return $this->initializationVector;
    }

    /**
     * @return string
     */
    public function getivrFlag()
    {
        return $this->ivrFlag;
    }

    /**
     * @return string
     */
    public function getnpc356chphoneidformat()
    {
        return $this->npc356availauthchannel;
    }

    /**
     * @return string
     */
    public function getnpc356chphoneid()
    {
        return $this->npc356chphoneid;
    }

    /**
     * @return string
     */
    public function getnpc356shopchannel()
    {
        return $this->npc356shopchannel;
    }

    /**
     * @return string
     */
    public function getnpc356availauthchannel()
    {
        return $this->npc356availauthchannel;
    }

    /**
     * @return string
     */
    public function getnpc356pareqchannel()
    {
        return $this->npc356itpcredential;
    }

    /**
     * @return string
     */
    public function getnpc356itpcredential()
    {
        return $this->npc356itpcredential;
    }

    /**
     * @return string
     */
    public function getauthDataName()
    {
        return $this->authDataName;
    }

    /**
     * @return string
     */
    public function getauthDatastrlen()
    {
        return $this->authDatastrlen;
    }

    /**
     * @return string
     */
    public function getauthDataType()
    {
        return $this->authDataType;
    }

    /**
     * @return string
     */
    public function getauthDataLabel()
    {
        return $this->authDataLabel;
    }

    /**
     * @return string
     */
    public function getauthDataPrompt()
    {
        return $this->authDataPrompt;
    }

    /**
     * @return string
     */
    public function getauthDataEncryptKey()
    {
        return $this->authDataEncryptKey;
    }

    /**
     * @return string
     */
    public function getauthDataEncryptType()
    {
        return $this->authDataEncryptType;
    }

    /**
     * @return string
     */
    public function getauthDataEncryptMandatory()
    {
        return $this->authDataEncryptMandatory;
    }

    /**
     * @return string
     */
    public function getivrPasswordStatus()
    {
        return $this->ivrPasswordStatus;
    }

    /**
     * @return string
     */
    public function getivrPassword()
    {
        return $this->ivrPassword;
    }

    /**
     * @return string
     */
    public function getitpauthtran()
    {
        return $this->itpauthtran;
    }

    /**
     * @return string
     */
    public function getitpauthiden()
    {
        return $this->itpauthiden;
    }

    /**
     * @return string
     */
    public function geturl()
    {
        return $this->url;
    }

    /**
     * @return string
     */
    public function getsavedcard()
    {
        return $this->savedcard;
    }

    /**
     * @return string
     */
    public function getpaymentdebitId()
    {
        return $this->paymentdebitId;
    }

    /**
     * @return string
     */
    public function getpaymentUrl()
    {
        return $this->paymentUrl;
    }

    /**
     * @param $val
     */
    public function setid($val)
    {
        $this->id = $val;
    }

    /**
     * @param $val
     */
    public function setpwd($val)
    {
        $this->pwd = $val;
    }

    /**
     * @param $val
     */
    public function setlivemode($val)
    {
        $this->liveMode = $val;
    }


    /**
     * @param $val
     */
    public function setaction($val)
    {
        $this->action = $val;
    }

    /**
     * @param $val
     */
    public function settransId($val)
    {
        $this->transId = $val;
    }

    /**
     * @param $val
     */
    public function setamt($val)
    {
        $this->amt = $val;
    }

    /**
     * @param $val
     */
    public function setresponseURL($val)
    {
        $this->responseURL = $val;
    }

    /**
     * @param $val
     */
    public function settrackId($val)
    {
        $this->trackId = $val;
    }

    /**
     * @param $val
     */
    public function setudf1($val)
    {
        $this->udf1 = $val;
    }

    /**
     * @param $val
     */
    public function setudf2($val)
    {
        $this->udf2 = $val;
    }

    /**
     * @param $val
     */
    public function setudf3($val)
    {
        $this->udf3 = $val;
    }

    /**
     * @param $val
     */
    public function setudf4($val)
    {
        $this->udf4 = $val;
    }

    /**
     * @param $val
     */
    public function setudf5($val)
    {
        $this->udf5 = $val;
    }

    /**
     * @param $val
     */
    public function setpaymentPage($val)
    {
        $this->paymentPage = $val;
    }

    /**
     * @param $val
     */
    public function setpaymentId($val)
    {
        $this->paymentId = $val;
    }

    /**
     * @param $val
     */
    public function setresult($val)
    {
        $this->result = $val;
    }

    /**
     * @param $val
     */
    public function setauth($val)
    {
        $this->auth = $val;
    }

    /**
     * @param $val
     */
    public function setref($val)
    {
        $this->ref = $val;
    }

    /**
     * @param $val
     */
    public function setavr($val)
    {
        $this->avr = $val;
    }

    /**
     * @param $val
     */
    public function setDate($val)
    {
        $this->date = $val;
    }

    /**
     * @param $val
     */
    public function setcurrency($val)
    {
        $this->currency = $val;
    }

    /**
     * @param $val
     */
    public function seterrorURL($val)
    {
        $this->errorURL = $val;
    }

    /**
     * @param $val
     */
    public function setlanguage($val)
    {
        $this->language = $val;
    }

    /**
     * @param $val
     */
    public function seterror($val)
    {
        $this->error = $val;
    }

    /**
     * @param $val
     */
    public function seterror_text($val)
    {
        $this->error_text = $val;
    }

    /**
     * @param $val
     */
    public function setrawResponse($val)
    {
        $this->rawResponse = $val;
    }

    /**
     * @param $val
     */
    public function setalias($val)
    {
        $this->alias = $val;
    }

    /**
     * @param $val
     */
    public function setDebugMsg($val)
    {
        $this->debugMsg = $val;
    }

    /**
     * @param $val
     */
    public function setresponseCode($val)
    {
        $this->responseCode = $val;
    }

    /**
     * @param $val
     */
    public function setzip($val)
    {
        $this->zip = $val;
    }

    /**
     * @param $val
     */
    public function setaddr($val)
    {
        $this->addr = $val;
    }

    /**
     * @param $val
     */
    public function setmember($val)
    {
        $this->member = $val;
    }

    /**
     * @param $val
     */
    public function setcvv2($val)
    {
        $this->cvv2 = $val;
    }

    /**
     * @param $val
     */
    public function setcvv2Verification($val)
    {
        $this->cvv2Verification = $val;
    }

    /**
     * @param $val
     */
    public function setType($val)
    {
        $this->type = $val;
    }

    /**
     * @param $val
     */
    public function setcard($val)
    {
        $this->card = $val;
    }

    /**
     * @param $val
     */
    public function setexpDay($val)
    {
        $this->expDay = $val;
    }

    /**
     * @param $val
     */
    public function setexpMonth($val)
    {
        $this->expMonth = $val;
    }

    /**
     * @param $val
     */
    public function setexpYear($val)
    {
        $this->expYear = $val;
    }

    /**
     * @param $val
     */
    public function seteci($val)
    {
        $this->eci = $val;
    }

    /**
     * @param $val
     */
    public function setcavv($val)
    {
        $this->cavv = $val;
    }

    /**
     * @param $val
     */
    public function setxid($val)
    {
        $this->xid = $val;
    }

    /**
     * @param $val
     */
    public function setresourcePath($val)
    {
        $this->resourcePath = $val;
    }

    /**
     * @param $val
     */
    public function setacsurl($val)
    {
        $this->acsurl = $val;
    }

    /**
     * @param $val
     */
    public function setpareq($val)
    {
        $this->pareq = $val;
    }

    /**
     * @param $val
     */
    public function setpares($val)
    {
        $this->pares = $val;
    }

    /**
     * @param $val
     */
    public function seterror_service_tag($val)
    {
        $this->error_service_tag = $val;
    }

    /**
     * @param $val
     */
    public function setkeystorePath($val)
    {
        $this->keystorePath = $val;
    }

    /**
     * @param $val
     */
    public function setseperator($val)
    {
        $this->seperator = $val;
    }

    /**
     * @param $val
     */
    public function setsep($val)
    {
        $this->sep = $val;
    }

    /**
     * @param $val
     */
    public function setwebAddress($val)
    {
        $this->webAddress = $val;
    }

    /**
     * @param $val
     */
    public function setkey($val)
    {
        $this->key = $val;
    }

    /**
     * @param $val
     */
    public function setinitializationVector($val)
    {
        $this->initializationVector = $val;
    }

    /**
     * @param $val
     */
    public function setivrFlag($val)
    {
        $this->ivrFlag = $val;
    }

    /**
     * @param $val
     */
    public function setnpc356chphoneidformat($val)
    {
        $this->npc356availauthchannel = $val;
    }

    /**
     * @param $val
     */
    public function setnpc356chphoneid($val)
    {
        $this->npc356chphoneid = $val;
    }

    /**
     * @param $val
     */
    public function setnpc356shopchannel($val)
    {
        $this->npc356shopchannel = $val;
    }

    /**
     * @param $val
     */
    public function setnpc356availauthchannel($val)
    {
        $this->npc356availauthchannel = $val;
    }

    /**
     * @param $val
     */
    public function setnpc356pareqchannel($val)
    {
        $this->npc356itpcredential = $val;
    }

    /**
     * @param $val
     */
    public function setnpc356itpcredential($val)
    {
        $this->npc356itpcredential = $val;
    }

    /**
     * @param $val
     */
    public function setauthDataName($val)
    {
        $this->authDataName = $val;
    }

    /**
     * @param $val
     */
    public function setauthDatastrlen($val)
    {
        $this->authDatastrlen = $val;
    }

    /**
     * @param $val
     */
    public function setauthDataType($val)
    {
        $this->authDataType = $val;
    }

    /**
     * @param $val
     */
    public function setauthDataLabel($val)
    {
        $this->authDataLabel = $val;
    }

    /**
     * @param $val
     */
    public function setauthDataPrompt($val)
    {
        $this->authDataPrompt = $val;
    }

    /**
     * @param $val
     */
    public function setauthDataEncryptKey($val)
    {
        $this->authDataEncryptKey = $val;
    }

    /**
     * @param $val
     */
    public function setauthDataEncryptType($val)
    {
        $this->authDataEncryptType = $val;
    }

    /**
     * @param $val
     */
    public function setauthDataEncryptMandatory($val)
    {
        $this->authDataEncryptMandatory = $val;
    }

    /**
     * @param $val
     */
    public function setivrPasswordStatus($val)
    {
        $this->ivrPasswordStatus = $val;
    }

    /**
     * @param $val
     */
    public function setivrPassword($val)
    {
        $this->ivrPassword = $val;
    }

    /**
     * @param $val
     */
    public function setitpauthtran($val)
    {
        $this->itpauthtran = $val;
    }

    /**
     * @param $val
     */
    public function setitpauthiden($val)
    {
        $this->itpauthiden = $val;
    }

    /**
     * @param $val
     */
    public function seturl($val)
    {
        $this->url = $val;
    }

    /**
     * @param $val
     */
    public function setsavedcard($val)
    {
        $this->savedcard = $val;
    }

    /**
     * @param $val
     */
    public function setpaymentdebitId($val)
    {
        $this->paymentdebitId = $val;
    }

    /**
     * @param $val
     */
    public function setpaymentUrl($val)
    {
        $this->paymentUrl = $val;
    }

    /**
     * @return string|null
     */
    public function buildHostRequest()
    {
        $strRequest = "";
        try {
            if (strlen($this->amt) > 0) {
                $strRequest .= "amt=" . $this->amt . "&";
            }
            if (strlen($this->action) > 0) {
                $strRequest .= "action=" . $this->action . "&";
            }
            if (strlen($this->responseURL) > 0) {
                $strRequest .= "responseURL=" . $this->responseURL . "&";
            }
            if (strlen($this->errorURL) > 0) {
                $strRequest .= "errorURL=" . $this->errorURL . "&";
            }
            if (strlen($this->trackId) > 0) {
                $strRequest .= "trackId=" . $this->trackId . "&";
            }
            if (strlen($this->udf1) > 0) {
                $strRequest .= "udf1=" . $this->udf1 . "&";
            }
            if (strlen($this->udf2) > 0) {
                $strRequest .= "udf2=" . $this->udf2 . "&";
            }
            if (strlen($this->udf3) > 0) {
                $strRequest .= "udf3=" . $this->udf3 . "&";
            }
            if (strlen($this->udf4) > 0) {
                $strRequest .= "udf4=" . $this->udf4 . "&";
            }
            if (strlen($this->udf5) > 0) {
                $strRequest .= "udf5=" . $this->udf5 . "&";
            }
            if (strlen($this->currency) > 0) {
                $strRequest .= "currencycode=" . $this->currency . "&";
            }
            if ($this->language != null && strlen($this->language) > 0) {
                $strRequest .= "langid=" . $this->language . "&";
            }
            if ($this->tokenFlg != null && strlen($this->tokenFlg) > 0) {
                $strRequest .= "tokenFlag=" . $this->tokenFlg . "&";
            }
            if ($this->tokenNumber != null && strlen($this->tokenNumber) > 0) {
                $strRequest .= "tokenNumber=" . $this->tokenNumber . "&";
            }
            return $strRequest;
        } catch (\Exception $e) {
            return null;
        }
    }

    /**
     * @return string|null
     */
    public function buildXMLRequest()
    {
        $requestbuffer = "";
        try {
            $requestbuffer . "<request>";
            if ($this->card != null) {
                if (strlen($this->card) > 0) {
                    $requestbuffer .= "<card>" . $this->card . "</card>";
                }
            }
            if ($this->cvv2 != null) {
                if (strlen($this->cvv2) > 0) {
                    $requestbuffer .= "<cvv2>" . $this->cvv2 . "</cvv2>";
                }
            }
            if ($this->currency != null) {
                if (strlen($this->currency) > 0) {
                    $requestbuffer .= "<currencycode>" . $this->currency . "</currencycode>";
                }
            }
            if ($this->expYear != null) {
                if (strlen($this->expYear) > 0) {
                    $requestbuffer .= "<expyear>" . $this->expYear . "</expyear>";
                }
            }
            if ($this->expMonth != null) {
                if (strlen($this->expMonth) > 0) {
                    $requestbuffer .= "<expmonth>" . $this->expMonth . "</expmonth>";
                }
            }
            if ($this->expDay != null) {
                if (strlen($this->expDay) > 0) {
                    $requestbuffer .= "<expday>" . "01" . "</expday>";
                }
            }
            if ($this->type != null) {
                if (strlen($this->type) > 0) {
                    $requestbuffer .= "<type>" . $this->type . "</type>";
                }
            }
            if ($this->transId != null) {
                if (strlen($this->transId) > 0) {
                    $requestbuffer .= "<transid>" . $this->transId . "</transid>";
                }
            }
            if ($this->zip != null) {
                if (strlen($this->zip) > 0) {
                    $requestbuffer .= "<zip>" . $this->zip . "</zip>";
                }
            }
            if ($this->addr != null) {
                if (strlen($this->addr) > 0) {
                    $requestbuffer .= "<addr>" . $this->addr . "</addr>";
                }
            }
            if ($this->member != null) {
                if (strlen($this->member) > 0) {
                    $requestbuffer .= "<member>" . $this->member . "</member>";
                }
            }
            if ($this->amt != null) {
                if (strlen($this->amt) > 0) {
                    $requestbuffer .= "<amt>" . $this->amt . "</amt>";
                }
            }
            if ($this->action != null) {
                if (strlen($this->action) > 0) {
                    $requestbuffer .= "<action>" . $this->action . "</action>";
                }
            }
            if ($this->trackId != null) {
                if (strlen($this->trackId) > 0) {
                    $requestbuffer .= "<trackid>" . $this->trackId . "</trackid>";
                }
            }
            if ($this->udf1 != null) {
                if (strlen($this->udf1) > 0) {
                    $requestbuffer .= "<udf1>" . $this->udf1 . "</udf1>";
                }
            }
            if ($this->udf2 != null) {
                if (strlen($this->udf2) > 0) {
                    $requestbuffer .= "<udf2>" . $this->udf2 . "</udf2>";
                }
            }
            if ($this->udf3 != null) {
                if (strlen($this->udf3) > 0) {
                    $requestbuffer .= "<udf3>" . $this->udf3 . "</udf3>";
                }
            }
            if ($this->udf4 != null) {
                if (strlen($this->udf4) > 0) {
                    $requestbuffer .= "<udf4>" . $this->udf4 . "</udf4>";
                }
            }
            if ($this->udf5 != null) {
                if (strlen($this->udf5) > 0) {
                    $requestbuffer .= "<udf5>" . $this->udf5 . "</udf5>";
                }
            }
            if ($this->currency != null) {
                if (strlen($this->currency) > 0) {
                    $requestbuffer .= "<currencycode>" . $this->currency . "</currencycode>";
                }
            }
            if ($this->tokenFlg != null) {
                if (strlen($this->tokenFlg) > 0) {
                    $requestbuffer .= "<tokenflag>" . $this->tokenFlg . "</tokenflag>";
                }
            }
            if ($this->tokenNumber != null) {
                if (strlen($this->tokenNumber) > 0) {
                    $requestbuffer .= "<tokennumber>" . $this->tokenNumber . "</tokennumber>";
                }
            }
            if ($this->eci != null) {
                if (strlen($this->eci) > 0) {
                    $requestbuffer .= "<eci>" . $this->eci . "</eci>";
                }
            }
            if ($this->errorURL != null) {
                if (strlen($this->errorURL) > 0) {
                    $requestbuffer .= "<errorURL>" . $this->errorURL . "</errorURL>";
                }
            }
            if ($this->responseURL != null) {
                if (strlen($this->responseURL) > 0) {
                    $requestbuffer .= "<responseURL>" . $this->responseURL . "</responseURL>";
                }
            }
            if ($this->ivrFlag != null) {
                if (strlen($this->ivrFlag) > 0) {
                    $requestbuffer .= "<ivrFlag>" . $this->ivrFlag . "</ivrFlag>";
                }
            }
            if ($this->npc356chphoneidformat != null) {
                if (strlen($this->npc356chphoneidformat) > 0) {
                    $requestbuffer .= "<npc356chphoneidformat>" . $this->npc356chphoneidformat . "</npc356chphoneidformat>";
                }
            }
            if ($this->npc356chphoneid != null) {
                if (strlen($this->npc356chphoneid) > 0) {
                    $requestbuffer .= "<npc356chphoneid>" . $this->npc356chphoneid . "</npc356chphoneid>";
                }
            }
            if ($this->npc356shopchannel != null) {
                if (strlen($this->npc356shopchannel) > 0) {
                    $requestbuffer .= "<npc356shopchannel>" . $this->npc356shopchannel . "</npc356shopchannel>";
                }
            }
            if ($this->npc356availauthchannel != null) {
                if (strlen($this->npc356availauthchannel) > 0) {
                    $requestbuffer .= "<npc356availauthchannel>" . $this->npc356availauthchannel . "</npc356availauthchannel>";
                }
            }
            if ($this->npc356pareqchannel != null) {
                if (strlen($this->npc356pareqchannel) > 0) {
                    $requestbuffer .= "<npc356pareqchannel>" . $this->npc356pareqchannel . "</npc356pareqchannel>";
                }
            }
            if ($this->npc356itpcredential != null) {
                if (strlen($this->npc356itpcredential) > 0) {
                    $requestbuffer .= "<npc356itpcredential>" . $this->npc356itpcredential . "</npc356itpcredential>";
                }
            }
            if ($this->ivrPasswordStatus != null && $this->ivrPasswordStatus . strlen() > 0)
                $requestbuffer .= "<ivrPasswordStatus>" . $this->ivrPasswordStatus . "</ivrPasswordStatus>";
            if ($this->ivrPassword != null && strlen($this->ivrPassword) > 0) {
                $requestbuffer .= "<ivrPassword>" . $this->ivrPassword . "</ivrPassword>";
            }
            if ($this->savedcard != null) {
                $requestbuffer .= "<savedcard>" . $this->savedcard . "</savedcard>";
            }
            return $requestbuffer;
        } catch (\Exception $e) {
            return null;
        }
    }

    /**
     * @return int
     */
    public function performPaymentInitializationHTTP()
    {
        $request = null;
        $requestbuffer = null;
        $xmlData = null;
        try {
            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            $keyParser = $objectManager->create('\Meetanshi\Oab\Model\KeyStoreOab');
            $requestbuffer = $this->buildHostRequest();
            $requestbuffer .= "id=".$this->getId()."&password=".$this->pwd."&";
            $this->logger->info("[performPaymentInitializationHTTP] liveMode => " . $this->liveMode);
            if($this->liveMode == 1){
                $this->webAddress = "https://securepayments.oabipay.com/trxns";
            } else {
                $this->webAddress = "https://certpayments.oabipay.com/trxns";
            }
            $cipheredText = $keyParser->encryptTripleDes($requestbuffer, $this->key);
            $request .= "&trandata=" . $cipheredText;
            $request .= "&errorURL=" . $this->errorURL . "&responseURL=" . $this->responseURL . "&tranportalId=".$this->getId();
            $this->webAddress .= "/PaymentHTTP.htm?param=paymentInit" . $request;
        } catch (\Exception $e) {
            $this->logger->info("Exception message [performPaymentInitializationHTTP] => " . $e->getMessage());
            $this->error = "Problem while encrypting request data". $e->getMessage();
            return -1;
        }
        return 0;
    }

    /**
     * @return int
     */
    public function performTransactionHTTP()
    {
        $request = null;
        $requestbuffer = null;
        $xmlData = null;
        try {
            $requestbuffer = $this->buildXMLRequest();
            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            $keyParser = $objectManager->create('\Meetanshi\Oab\Model\KeyStoreOab');
            $this->key = $keyParser->parseKeyStore($this->keystorePath);
            $xmlData = $this->parseResource($this->key, $this->resourcePath, $this->alias);
            if ($xmlData == null) {
                $this->error = "Alias name does not exits";
                return -1;
            } else {
                $xmlData = $this->parseXMLRequest($xmlData);
            }
            $requestbuffer .= "<id>" . $xmlData["id"] . "</id>";
            $requestbuffer .= "<password>" . $xmlData["password"] . "</password>";
            $requestbuffer . "</request>";
            if ($this->responseURL == null || strlen(trim($this->responseURL)) <= 0) {
                $this->error = "Response URL is Invalid or NULL";
                return -1;
            }
            $this->key = $xmlData["resourceKey"];
            $cipheredText = $keyParser->encryptData($requestbuffer, $this->key);
            $request .= "&trandata=" . $cipheredText;
            $request .= "&errorURL=" . $this->errorURL;
            $request .= "&responseURL=" . $this->responseURL;
            $request .= "&tranportalId=" . $xmlData["id"];
            $this->webAddress = $xmlData["webaddress"];
            $this->setid($xmlData["id"] . "");
            $this->webAddress .= "/tranPipeHTTP.htm?param=tranInit" . $request;
            return 0;
        } catch (\Exception $e) {
            $this->error = "Error :(";
            return -1;
        }
    }

    /**
     * @param $key
     * @param $resourcePath
     * @param $alias
     * @return false|string|null
     */
    public function parseResource($key, $resourcePath, $alias)
    {
        $xmlData = null;
        $key = null;
        try {
            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            $parseResouce = $objectManager->create('\Meetanshi\Oab\Model\ParseResourceOab');
            $parseResouce->setResourcePath($resourcePath);
            $parseResouce->setKey($this->key);
            $parseResouce->setAlias($alias);
            $parseResouce->createCGZFromCGN();
            $xmlData = $parseResouce->readZip();
            return $xmlData;
        } catch (\Exception $e) {
            return null;
        }
    }


    /**
     * @return int
     */
    public function performTransaction()
    {
        $request = null;
        $xmlData = null;
        $requestbuffer = null;
        $hm = null;
        try {
            $requestbuffer = $this->buildXMLRequest();
            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            $keyParser = $objectManager->create('\Meetanshi\Oab\Model\KeyStoreOab');
            $this->key = $keyParser->parseKeyStore($this->keystorePath);
            $xmlData = $this->parseResource($this->key, $this->resourcePath, $this->alias);
            if ($xmlData == null) {
                $this->error = "Alias name does not exits";
                return -1;
            } else {
                $hm = $this->parseXMLRequest($xmlData);
            }
            $requestbuffer .= "<id>" . $hm["id"] . "</id>";
            $requestbuffer .= "<password>" . $hm["password"] . "</password>";
            $requestbuffer . "</request>";
            $this->webAddress = $hm["webaddress"];
            $response = $this->performTranPortalTransaction($requestbuffer, $this->webAddress);
            $resultMap = $this->parseResponse($response);
            return $this->setTransactionData($resultMap);
        } catch (\Exception $e) {
            $this->error = "Error! " . $e->getMessage();
            return -1;
        }
    }


    /**
     * @param $request
     * @param $webAddress
     * @return bool|string|null
     */
    public function performTranPortalTransaction($request, $webAddress)
    {
        $webAddress .= "/tranPipe.htm?param=tranInit";
        $tranType = "tran";
        $response = $this->sendMessage($request, $webAddress, $tranType);
        return $response;
    }

    /**
     * @param $request
     * @param $webAddress
     * @param $tranType
     * @return bool|string|null
     */
    public function sendMessage($request, $webAddress, $tranType)
    {
        $contentType = "";
        $result = "";
        if (strcmp($tranType, "host"))
            $contentType = "Content-Type:application/x-www-form-urlencoded";
        if (strcmp($tranType, "tran"))
            $contentType = "Content-Type:application/xml";
        if (strlen($webAddress) <= 0) {
            return null;
        }
        $curl = curl_init();
        if (strlen($request) > 0) {
            curl_setopt($curl, CURLOPT_URL, $webAddress);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($curl, CURLOPT_FRESH_CONNECT, TRUE);
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, true);
            curl_setopt($curl, CURLOPT_HTTPHEADER, array(
                "Cache-Control: no-cache",
                $contentType
            ));
            curl_setopt($curl, CURLOPT_POSTFIELDS, $request);
            $header_size = curl_getinfo($curl, CURLINFO_HEADER_SIZE);
            $result = curl_exec($curl);
            if ($result == false) {
            }
            curl_close($curl);
        }
        return $result;
    }


    /**
     * @param $response
     * @return int
     */
    public function parseEncryptedResultHttp($response)
    {
        $xmlData = null;
        try {
            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            $keyParser = $objectManager->create('\Meetanshi\Oab\Model\KeyStoreOab');
            $this->key = $keyParser->parseKeyStore($this->keystorePath);
            $xmlData = $this->parseResource($this->key, $this->resourcePath, $this->alias);
            if ($xmlData != null) {
                $hm = $this->parseXMLRequest($xmlData);
            } else {
                $this->error = "Alias name does not exits";
            }
            $this->key = $hm["resourceKey"];
            $cipheredText = $this->decryptData($response, $this->key);
            if ($cipheredText == null) {
                $this->error = "Invalid response";
                return -1;
            }
            return parsetrandata($cipheredText);
        } catch (\Exception $e) {
            $this->error = "Internal Error: " + $e->getMessage();
            return -1;
        }
    }

    /**
     * @return int
     */
    public function performVbVTransaction()
    {
        $request = null;
        $xmlData = null;
        $requestbuffer = null;
        $hm = null;
        try {
            $requestbuffer = $this->buildXMLRequest();
            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            $keyParser = $objectManager->create('\Meetanshi\Oab\Model\KeyStoreOab');
            $this->key = $keyParser->parseKeyStore($this->keystorePath);
            $xmlData = $this->parseResource($this->key, $this->resourcePath, $this->alias);
            if ($xmlData == null) {
                $this->error = "Alias name does not exits";
                return -1;
            } else {
                $hm = $this->parseXMLRequest($xmlData);
            }
            $requestbuffer .= "<id>" . $hm["id"] . "</id>";
            $requestbuffer .= "<password>" . $hm["password"] . "</password>";
            $requestbuffer . "</request>";
            if ($this->responseURL == null || strlen(trim($this->responseURL)) == 0) {
                return -1;
            }
            $this->key = $hm["resourceKey"];
            $cipheredText = $keyParser->encryptData($requestbuffer, $this->key);
            $request = "&trandata=" . $cipheredText . "&errorURL=" . $this->errorURL . "&responseURL=" . $this->responseURL . "&tranportalId=" . $hm["id"];
            $this->webAddress = $hm["webaddress"];
            $this->webAddress .= "/VPAS.htm?actionVPAS=VbvVEReqProcessHTTP" . $request;
            return 0;
        } catch (\Exception $e) {
            $this->error = "Error! " . $e->getMessage();
            return -1;
        }
    }

    /**
     * @param $trandata
     * @return int
     */
    public function parseEncryptedRequest($trandata) {
        $result = 0;
        $xmlData = null;
        $hm = null;
        try {
            if ($trandata == null) {
                return 0;
            }
            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            $keyParser = $objectManager->create('\Meetanshi\Oab\Model\KeyStoreOab');
            $trandata = $keyParser->decryptTripleDes($trandata, $this->key);
            $this->logger->info("Exception message [parseEncryptedRequest] => " . $this->key);
            $this->logger->info("Exception message [trandata] => " . $trandata);
            $result = $this->parsetrandata($trandata);
            return $result;
        } catch (\Exception $e) {
            $this->logger->info("Exception message [parseEncryptedRequest] => " . $e->getMessage());
            //return -1;
            throw $e;
        }
    }

    /**
     * @param $response
     * @return int
     */
    public function parseEncryptedResult($response)
    {
        $xmlData = null;
        $hm = null;
        $resultMap = null;
        try {
            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            $keyParser = $objectManager->create('\Meetanshi\Oab\Model\KeyStoreOab');
            $this->key = $keyParser->parseKeyStore($this->keystorePath);
            $xmlData = $this->parseResource($this->key, $this->resourcePath, $this->alias);
            if ($xmlData != null) {
                $hm = $this->parseXMLRequest($xmlData);
            } else {
                $this->error = "Alias name does not exits";
            }
            $this->key = $hm["resourceKey"];
            $response = $keyParser->decryptData($response, $this->key);
            $resultMap = $this->parseResponse($response);
            return $this->setTransactionData($resultMap);
        } catch (\Exception $e) {
            return -1;
        }
    }

    /**
     * @param $request
     * @return array|null
     */
    public function parseXMLRequest($request)
    {
        try {
            $responseMap = null;
            $request = trim($request);
            $request = substr($request, strpos($request, "<id>"), strlen($request) - strpos($request, "<id>"));
            $request = str_replace("</terminal>", "", $request);
            $pos = strpos($request, "<") == 0;
            if ($request == null || (strlen($request) < 0) || $pos === false) {
                return null;
            } else {
                try {
                    $responseMap = $this->parseResponse($request);
                } catch (\Exception $ex) {
                    return null;
                }
            }
            return $responseMap;
        } catch (\Exception $e) {
            return null;
        }
    }

    /**
     * @param $response
     * @return array|null
     */
    public function parseResponse($response)
    {
        $begin = 0;
        $end = 0;
        $start = null;
        $value = null;
        $maps = [];
        $response = trim($response);
        $pos = strpos($response, "<") == 0;
        if ($response == null || (strlen($response) < 0) || $pos === false) {
            return null;
        } else {
            do {
                if ((strpos($response, "<") !== false) && (strpos($response, ">") !== false)) {
                    $start = substr($response, ($ind = strpos($response, "<")) + 1, ((strpos($response, ">") - 1) - $ind));
                    $mapKey = substr($response, ($ind = strpos($response, ">")) + 1, ((strpos($response, "</" . $start . ">") - 1) - $ind));
                    $response = substr($response, $from = strpos($response, "</" . $start . ">") + strlen($start) + 3, strrpos($response, ">") - $from + 1);
                    $maps[$start] = $mapKey;
                } else {
                    break;
                }
            } while (strlen($response) > 0);
        }
        return $maps;
    }

    /**
     * @param $resultMap
     * @return int
     */
    public function setTransactionData($resultMap)
    {
        try {
            if (isset($resultMap["error"])) {
                $this->error = trim($resultMap["error"]);
            }
            if (isset($resultMap["url"]))
                $this->acsurl = trim($resultMap["url"]);
            if (isset($resultMap["PAReq"]))
                $this->pareq = trim($resultMap["PAReq"]);
            if (isset($resultMap["paymentid"]))
                $this->paymentId = trim($resultMap["paymentid"]);
            if (isset($resultMap["payid"]))
                $this->paymentId = trim($resultMap["payid"]);
            if (isset($resultMap["eci"]))
                $this->eci = trim($resultMap["eci"]);
            if (isset($resultMap["result"]))
                $this->result = trim($resultMap["result"]);
            if (isset($resultMap["auth"]))
                $this->auth = trim($resultMap["auth"]);
            if (isset($resultMap["ref"]))
                $this->ref = trim($resultMap["ref"]);
            if (isset($resultMap["avr"]))
                $this->avr = trim($resultMap["avr"]);
            if (isset($resultMap["postdate"]))
                $this->date = trim($resultMap["postdate"]);
            if (isset($resultMap["tranid"]))
                $this->transId = trim($resultMap["tranid"]);
            if (isset($resultMap["amt"]))
                $this->amt = trim($resultMap["amt"]);
            if (isset($resultMap["trackid"]))
                $this->trackId = trim($resultMap["trackid"]);
            if (isset($resultMap["udf1"]))
                $this->udf1 = trim($resultMap["udf1"]);
            if (isset($resultMap["udf2"]))
                $this->udf2 = trim($resultMap["udf2"]);
            if (isset($resultMap["udf3"]))
                $this->udf3 = trim($resultMap["udf3"]);
            if (isset($resultMap["udf4"]))
                $this->udf4 = trim($resultMap["udf4"]);
            if (isset($resultMap["udf5"]))
                $this->udf5 = trim($resultMap["udf5"]);
            if (isset($resultMap["error_code_tag"]))
                $this->error = trim($resultMap["error_code_tag"]);
            if (isset($resultMap["error_service_tag"]))
                $this->error_service_tag = trim($resultMap["error_service_tag"]);
            if (isset($resultMap["error_text"]))
                $this->error_text = trim($resultMap["error_text"]);
            if (isset($resultMap["responsecode"]))
                $this->responseCode = trim($resultMap["responsecode"]);
            if (isset($resultMap["tokencustid"])) {
                $this->tokenCustomerId = $resultMap["tokencustid"];
            }
            if (isset($resultMap["cvv2response"]))
                $this->cvv2Verification = trim($resultMap["cvv2response"]);
            if (isset($resultMap["paymentId"]))
                $this->paymentdebitId = trim($resultMap["paymentId"]);
        } catch (\Exception $e) {
            return -1;
        }
        return 0;
    }

    /**
     * @param $trandata
     * @return int
     */
    public function parsetrandata($trandata)
    {
        try {
            $splitData = $this->splitData($trandata);
            if (isset($splitData["paymentid"])) {
                $this->paymentId = $splitData["paymentid"];
            }
            if (isset($splitData["result"])) {
                $this->result = $splitData["result"];
            }
            if (isset($splitData["udf1"])) {
                $this->udf1 = $splitData["udf1"];
            }
            if (isset($splitData["udf2"])) {
                $this->udf2 = $splitData["udf2"];
            }
            if (isset($splitData["udf3"])) {
                $this->udf3 = $splitData["udf3"];
            }
            if (isset($splitData["udf4"])) {
                $this->udf4 = $splitData["udf4"];
            }
            if (isset($splitData["udf5"])) {
                $this->udf5 = $splitData["udf5"];
            }
            if (isset($splitData["amt"])) {
                $this->amt = $splitData["amt"];
            }
            if (isset($splitData["auth"])) {
                $this->auth = $splitData["auth"];
            }
            if (isset($splitData["ref"])) {
                $this->ref = $splitData["ref"];
            }
            if (isset($splitData["tranid"])) {
                $this->transId = $splitData["tranid"];
            }
            if (isset($splitData["postdate"])) {
                $this->date = $splitData["postdate"];
            }
            if (isset($splitData["trackId"])) {
                $this->trackId = $splitData["trackId"];
            }
            if (isset($splitData["trackid"])) {
                $this->trackId = $splitData["trackid"];
            }
            if (isset($splitData["action"])) {
                $this->action = $splitData["action"];
            }
            if (isset($splitData["Error"])) {
                $this->error = $splitData["Error"];
            }
            if (isset($splitData["ErrorText"])) {
                $this->error_text = $splitData["ErrorText"];
            }
            if (isset($splitData["error_text"])) {
                $this->error_text = $splitData["error_text"];
            }
            if (isset($splitData["tokencustid"])) {
                $this->tokenCustomerId = $splitData["tokencustid"];
            }
        } catch (\Exception $e) {
            //$this->logger->info("Exception message [parseEncryptedRequest] => " . $e->getMessage());
            //return -1;
            echo $e->getMessage();
            throw $e;
        }
        return 0;
    }

    /**
     * @param $trandata
     * @return mixed
     */
    public function splitData($trandata)
    {
        $splitData = array();
        $data = explode("&", $trandata);
        foreach ($data as $value) {
            $temp = explode("=", $value);
            if (count($temp) > 1) {
                $splitData[$temp[0]] = $temp[1];
            }
        }
        return $splitData;
    }
}
