<?php

namespace Meetanshi\Oab\Model;

/**
 * Class KeyStoreOab
 * @package Meetanshi\Oab\Model
 */
class KeyStoreOab
{
    /**
     * @param $keyToBeEncrypted
     * @param $keyStorePath
     */
    public function doSimleEncrypt($keyToBeEncrypted, $keyStorePath)
    {
        $hexData = ($keyToBeEncrypted);
        $encData = $this->xor_this($keyToBeEncrypted);
        $myfile = fopen($keyStorePath . "keystore.pooh", "w");
        if($myfile === false) {
            print_r("Unable to open file!");
        }
        fwrite($myfile, $encData);
        fflush($myfile);
        fclose($myfile);
    }

    /**
     * @param $keyStorePath
     * @return string
     */
    public function parseKeyStore($keyStorePath)
    {
        $myfile = fopen($keyStorePath . "keystore.pooh", "r");
        if($myfile === false) {
            print_r("Unable to open file!");
        }
        $decData = $this->xor_this(fread($myfile, filesize($keyStorePath . "keystore.pooh")));
        fclose($myfile);
        return $decData;
    }

    /**
     * @param $text
     * @return string
     */
    public function xor_this($text)
    {
        $key = "frtkj";
        $i = 0;
        $encrypted = "";
        foreach (str_split($text) as $char) {
            
        }
        return $encrypted;
    }

    /**
     * @param $payload
     * @param $key
     * @return string
     */
    public function encryptData($payload, $key)
    {
        $chiper = "des-ecb";
        if ((strlen($payload) % 8) != 0) {
            $payload = $this->rightPadZeros($payload);
        }
        //$iv = openssl_random_pseudo_bytes(89);
        $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length($chiper));
        $encrypted = openssl_encrypt($payload, $chiper, $key, OPENSSL_RAW_DATA, $iv);
        $encrypted = unpack("C*", ($encrypted));
        $encrypted = $this->byteArray2Hex($encrypted);
        return strtoupper($encrypted);
    }

    public function encryptTripleDes($data, $key) {
        $ciphertext_raw = openssl_encrypt($data, 
            'des-ede3', // des-ede3-ecb
            $key, 
            OPENSSL_RAW_DATA
        );
        $encrypted = unpack("C*", ($ciphertext_raw));
        //$ciphertext_hex = bin2hex($ciphertext_raw);
        $ciphertext_hex = $this->byteArray2Hex($encrypted);
        return strtoupper($ciphertext_hex);
	}

    public function decryptTripleDes($data, $key) {
        $data = $this->hex2ByteArray($data);
        $data = $this->byteArray2String($data);
        $data = base64_encode($data);
        $text_raw = openssl_decrypt($data, 
            'des-ede3', // des-ede3-ecb
            $key, 
            OPENSSL_ZERO_PADDING
        );
        return $text_raw;
	}

    /**
     * @param $data
     * @param $key
     * @return false|string
     */
    public function decryptData($data, $key)
    {
        $chiper = "des-ede3";
        $data = $this->hex2ByteArray($data);
        $data = $this->byteArray2String($data);
        $data = base64_encode($data);
        $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length($chiper));
        //$iv = openssl_random_pseudo_bytes(1);
        $decrypted = openssl_decrypt($data, $chiper, $key, OPENSSL_ZERO_PADDING, $iv);
        return $decrypted;
    }

    /**
     * @param $hexString
     * @return array|false
     */
    public function hex2ByteArray($hexString)
    {
        $string = hex2bin($hexString);
        return unpack("C*", $string);
    }

    /**
     * @param $byteArray
     * @return string
     */
    public function byteArray2String($byteArray)
    {
        $chars = array_map("chr", $byteArray);
        return join($chars);
    }

    /**
     * @param $message
     */
    public function pkcs5_pad($message)
    {
        $message_padded = $message;
        if (strlen($message_padded) % 8) {
            $message_padded = str_pad($message_padded, strlen($message_padded) + 8 - strlen($message_padded) % 8, "");
        }
    }

    /**
     * @param $Str
     * @return string|null
     */
    public function rightPadZeros($Str)
    {
        if (null == $Str) {
            return null;
        }
        $PadStr = $Str;
        for ($i = strlen($Str); ($i % 8) != 0; $i++) {
            $PadStr .= "^";
        }
        return $PadStr;
    }

    /**
     * @param $byteArray
     * @return string
     */
    public function byteArray2Hex($byteArray)
    {
        $chars = array_map("chr", $byteArray);
        $bin = join($chars);
        return bin2hex($bin);
    }
}
