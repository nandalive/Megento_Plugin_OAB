<?php

namespace Meetanshi\Oab\Setup;


use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Meetanshi\Oab\Helper\Deploy;

/**
 * Class InstallData
 * @package Meetanshi\Oab\Setup
 */
class InstallData implements InstallDataInterface
{
    /**
     * @var Deploy
     */
    protected $deployHelper;

    /**
     * InstallData constructor.
     * @param Deploy $deployHelper
     */
    public function __construct(Deploy $deployHelper
    )
    {
        $this->deployHelper = $deployHelper;
    }

    /**
     * @param ModuleDataSetupInterface $setup
     * @param ModuleContextInterface $context
     */
    public function install(
        ModuleDataSetupInterface $setup,
        ModuleContextInterface $context
    )
    {
        $this->deployOab();
    }

    /**
     *
     */
    protected function deployOab()
    {
        $p = strrpos(__DIR__, DIRECTORY_SEPARATOR);
        $modulePath = $p ? substr(__DIR__, 0, $p) : __DIR__;
        $this->deployHelper->deployOab($modulePath);
    }
}
