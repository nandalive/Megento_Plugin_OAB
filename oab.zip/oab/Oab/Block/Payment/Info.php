<?php

namespace oab\Oab\Block\Payment;

use Magento\Payment\Block\ConfigurableInfo;

/**
 * Class Info
 * @package oab\Oab\Block\Payment
 */
class Info extends ConfigurableInfo
{
    /**
     * @var string
     */
    protected $_template = 'oab_Oab::payment/info.phtml';

    /**
     * @param string $field
     * @return \Magento\Framework\Phrase|string
     */
    public function getLabel($field)
    {
        switch ($field) {
            case 'method_title':
                return __('Method Title');
            case 'payment_id':
                return __('Payment Id');
            case 'result':
                return __('Transaction Status');
            case 'tran_id':
                return __('Transaction ID');
            case 'reference_id':
                return __('Reference ID');
            case 'track_id':
                return __('Tracking Id');
            default:
                return parent::getLabel($field);
        }
    }
}
