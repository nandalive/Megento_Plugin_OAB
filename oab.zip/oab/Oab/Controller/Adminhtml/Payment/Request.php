<?php

namespace oab\Oab\Controller\Adminhtml\Payment;

use Magento\Sales\Model\OrderFactory;
use oab\Oab\Helper\Data;
use Magento\Backend\App\Action;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Data\Form\FormKey\Validator;
use oab\Oab\Model\IPayOabPipe;

/**
 * Class Request
 * @package oab\Oab\Controller\Adminhtml\Payment
 */
class Request extends Action
{
    /**
     * @var OrderFactory
     */
    protected $orderFactory;

    /**
     * @var Data
     */
    protected $helper;
    /**
     * @var Validator
     */
    protected $formKeyValidator;

    /**
     * @var IPayOabPipe
     */
    protected $iPayPipe;


    /**
     * Request constructor.
     * @param Action\Context $context
     * @param OrderFactory $orderFactory
     * @param Validator $formKeyValidator
     * @param Data $helper
     * @param IPayOabPipe $iPayPipe
     * @param array $params
     */
    public function __construct(
        Action\Context $context,
        OrderFactory $orderFactory,
        Validator $formKeyValidator,
        Data $helper,
        IPayOabPipe $iPayPipe,
        $params = []
    )
    {
        $this->orderFactory = $orderFactory;
        $this->helper = $helper;
        $this->formKeyValidator = $formKeyValidator;
        $this->iPayPipe = $iPayPipe;
        parent::__construct($context);
    }

    /**
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\Result\Redirect|\Magento\Framework\Controller\ResultInterface
     * @throws \Exception
     */
    public function execute()
    {
        $params = $this->getRequest()->getParams();
        if (!$this->formKeyValidator->validate($this->getRequest())) {
            $this->messageManager->addErrorMessage(__('Unable to process Inquiry Service.'));
            return $this->resultRedirectFactory->create()->setPath(
                'sales/order/view',
                [
                    'order_id' => $params['order_id']
                ]
            );
        }

        if ($params) {
            $resultRedirect = $this->resultRedirectFactory->create();
            $config = DirectoryList::getDefaultConfig();
            $resourcePath = BP . '/' . $config['base']['path'] . "/oab/";

            $order = $this->orderFactory->create()->load($params['order_id']);
            $storeId = $order->getStoreId();

            $payment = $order->getPayment()->getAdditionalInformation();

            $currency = "512";
            $language = $this->helper->getPaymentLanguage();
            $receiptURL = $this->helper->getSuccessUrl($storeId);
            $errorURL = $this->helper->getSuccessUrl($storeId);
            $tranportalId = $this->helper->getTranportalId();
            $tranportalPwd = $this->helper->getTranportalPwd();
            $resourceKey = $this->helper->getResourceKey();
            $liveMode = $this->helper->getLiveMode();
            $ipayPipe = $this->_objectManager->create('\oab\Oab\Model\IPayOabPipe');
            $ipayPipe->setResourcePath(trim($resourcePath));
            $ipayPipe->setKeystorePath(trim($resourcePath));
            $ipayPipe->setAlias(trim($aliasName));
            $ipayPipe->setCurrency(trim($currency));
            $ipayPipe->setLanguage(trim($language));
            $ipayPipe->setResponseURL(trim($receiptURL));
            $ipayPipe->setErrorURL(trim($errorURL));

            $ipayPipe->setAction(8);

            if (array_key_exists('tran_id', $payment)) {
                $transId = $payment['tran_id'];
                $udf5 = '';
            } else {
                $transId = $order->getIncrementId();
                $udf5 = 'TrackID';
            }

            $ipayPipe->setTransId($transId);

            $ipayPipe->setUdf5($udf5);

            $ipayPipe->setAmt(round($order->getGrandTotal(), 3));
            $ipayPipe->setTrackId($order->getIncrementId());

            $result = $ipayPipe->performTransaction();

            if ($result == '0') {
                if ($ipayPipe->geterror() != null && $ipayPipe->geterror() != "") {
                    $this->messageManager->addErrorMessage(__($ipayPipe->geterror()));
                }
                if ($ipayPipe->getresult() == "CAPTURED" || $ipayPipe->getresult() == "SUCCESS") {
                    $paymentID = $ipayPipe->getpaymentId();
                    $presult = $ipayPipe->getresult();
                    $tranId = $ipayPipe->gettransId();
                    $ref = $ipayPipe->getref();
                    $trackId = $ipayPipe->gettrackId();
                    $payments = $order->getPayment();
                    $payments->setAdditionalInformation('payment_id', $paymentID);
                    $payments->setAdditionalInformation('result', $presult);
                    $payments->setAdditionalInformation('tran_id', $tranId);
                    $payments->setAdditionalInformation('reference_id', $ref);
                    $payments->setAdditionalInformation('track_id', $trackId);

                    $payments->setAdditionalInformation((array)$payments->getAdditionalInformation());
                    $payments->save();
                    $order->save();
                    $this->messageManager->addSuccessMessage(__('You have successfully inquired OAB Service.'));
                }
                if ((trim($ipayPipe->getresult()) != "CAPTURED") && (trim($ipayPipe->getresult()) != "SUCCESS")) {
                    $this->messageManager->addErrorMessage(__($ipayPipe->getresult()));
                }

            }

            return $this->resultRedirectFactory->create()->setPath(
                'sales/order/view',
                [
                    'order_id' => $order->getId()
                ]
            );
        }
    }

    /**
     * @return bool
     */
    protected function _isAllowed()
    {
        return true;
    }
}
