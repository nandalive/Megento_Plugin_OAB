<?php

namespace oab\Oab\Controller\Payment;

use oab\Oab\Controller\Main;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\UrlInterface;
use Magento\Sales\Model\Order;

class Redirect extends Main
{
    public function execute()
    {
        $orderIncrementId = $this->checkoutSession->getLastRealOrderId();

        $order = $this->orderFactory->create()->loadByIncrementId($orderIncrementId);

        $config = DirectoryList::getDefaultConfig();
        $resourcePath = BP . '/' . $config['base']['path'] . "/oab/";

        $storeId = $order->getStoreId();

        $tranTrackid = $orderIncrementId;

        $currency = "512";
        $language = $this->helper->getPaymentLanguage();
        $receiptURL = $this->helper->getSuccessUrl($storeId);
        $errorURL = $this->helper->getSuccessUrl($storeId);
        $tranportalId = $this->helper->getTranportalId();
        $tranportalPwd = $this->helper->getTranportalPwd();
        $resourceKey = $this->helper->getResourceKey();
        $liveMode = $this->helper->getLiveMode();

        $myObj = $this->iPayPipe;
        $myObj->setResourcePath(trim($resourcePath));
        $myObj->setKeystorePath(trim($resourcePath));
        $myObj->setCurrency(trim($currency));
        $myObj->setLanguage(trim($language));
        $myObj->setResponseURL(trim($receiptURL));
        $myObj->setErrorURL(trim($errorURL));

        $myObj->setAction(1);
        $myObj->setAmt(round($order->getGrandTotal(), 3));
        $myObj->setTrackId($tranTrackid);
        $myObj->setId($tranportalId);
        $myObj->setpwd($tranportalPwd);
        $myObj->setkey($resourceKey);
        $myObj->setlivemode($liveMode);
        $myObj->setLogger($this->logger);
        $result = $myObj->performPaymentInitializationHTTP();

        if (trim($result) == 0) {
            $url = $myObj->getWebAddress();
        } else {
            $error = $myObj->getError();
            $order->addStatusHistoryComment($error, Order::STATE_CANCELED)->setIsCustomerNotified(true);
            $order->cancel();
            $order->save();
            $this->messageManager->addErrorMessage($error);
            $this->checkoutSession->restoreQuote();
            $this->_redirect('checkout/cart');
            return;
        }

        $resultRedirect = $this->resultRedirectFactory->create();

        $message = 'Customer is redirected to Knet';

        $order->setState(Order::STATE_NEW, true, $message);
        $order->save();

        return $resultRedirect->setUrl($url);
    }
}
