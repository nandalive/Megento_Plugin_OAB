<?php

namespace oab\Oab\Model;

/**
 * Class ParseResourceOab
 * @package oab\Oab\Model
 */
class ParseResourceOab
{
    /**
     * @var
     */
    public $resourcePath;
    /**
     * @var
     */
    public $key;
    /**
     * @var
     */
    public $error;
    /**
     * @var
     */
    public $alias;

    /**
     * @return mixed
     */
    public function getResourcePath()
    {
        return $this->resourcePath;
    }

    /**
     * @return mixed
     */
    public function getKey()
    {
        return $this->key;
    }

    /**
     * @return mixed
     */
    public function getAlias()
    {
        return $this->alias;
    }

    /**
     * @param $path
     */
    public function setResourcePath($path)
    {
        $this->resourcePath = $path;
    }

    /**
     * @param $alias
     */
    public function setAlias($alias)
    {
        $this->alias = $alias;
    }

    /**
     * @param $key
     */
    public function setKey($key)
    {
        $this->key = $key;
    }

    /**
     * @return bool
     */
    public function createCGZFromCGN()
    {
        {
            $filenameInput = $this->getResourcePath() . "resource.cgn";
            $handleInput = fopen($filenameInput, "r");
            $contentsInput = fread($handleInput, filesize($filenameInput));
            $filenameOutput = $this->getResourcePath() . "resource.cgz";
            @unlink($filenameOutput);
            $handleOutput = fopen($filenameOutput, "w");
            $dec = $this->decryptData($contentsInput, $this->key);
            fwrite($handleOutput, $dec);
            fclose($handleInput);
            fclose($handleOutput);
        }
        return true;
    }

    /**
     * @return false|string
     */
    public function readZip()
    {
        $s = "";
        {
            $filenameInput = $this->getResourcePath() . "resource.cgz";
            $zip = new \ZipArchive;
            $zp = $zip->open($filenameInput);
            if ($zp === TRUE) {
                $zip->extractTo($this->resourcePath);
                $zip->close();
            } else {
                print_r("failed");
                $this->error = "Failed to unzip file";
            }
            if (strlen($this->error) === 0) {
                $xmlNameInput = $this->resourcePath . $this->getAlias() . ".xml";
                $xmlHandleInput = fopen($xmlNameInput, "r");
                $xmlContentsInput = fread($xmlHandleInput, filesize($xmlNameInput));
                fclose($xmlHandleInput);
                unlink($xmlNameInput);
                $s = $xmlContentsInput;
                $s = $this->decryptData($s, $this->key);
            } else {
                $this->error = "Unable to open resource";
            }
            return $s;
        }
    }

    /**
     * @param $data
     * @param $key
     * @return false|string
     */
    public function decryptData($data, $key)
    {
        $method = "des-ede";
        $data = base64_encode($data);
        $data = openssl_decrypt($data, $method, $key);
        $len = strlen($data);
//        $pad    = ord($data[$len]);
//        $decr   = substr($data, 0, strlen($data) - $pad);
        $decr = substr($data, 0, strlen($data) - 0);
        return $decr;
    }

    /**
     * @param $s
     * @return array
     */
    public function getBytes($s)
    {
        $hex_ary = array();
        $size = strlen($s);
        for ($i = 0; $i < $size; $i++)
            $hex_ary[] = chr(ord($s[$i]));
        return $hex_ary;
    }

    /**
     * @param $byteArray
     * @return string
     */
    public function getString($byteArray)
    {
        $s = "";
        foreach ($byteArray as $byte) {
            $s .= $byte;
        }
        return $s;
    }

    /**
     * @param $Haystack
     * @param $Needle
     * @return bool
     */
    public function StartsWith($Haystack, $Needle)
    {
        return strpos($Haystack, $Needle) === 0;
    }

    /**
     * @param $Haystack
     * @param $Needle
     * @return bool
     */
    public function EndsWith($Haystack, $Needle)
    {
        return strrpos($Haystack, $Needle) === strlen($Haystack) - strlen($Needle);
    }

    /**
     * @param $string
     * @return string
     */
    public function xor_string($string)
    {
        $buf = "";
        $size = strlen($string);
        for ($i = 0; $i < $size; $i++)
            $buf .= chr(ord($string[$i]) ^ 255);
        return $buf;
    }
}
