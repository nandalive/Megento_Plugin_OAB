<?php
use \Magento\Framework\Component\ComponentRegistrar;

\Magento\Framework\Component\ComponentRegistrar::register(
    ComponentRegistrar::MODULE,
    'oab_Oab',
    __DIR__
);
